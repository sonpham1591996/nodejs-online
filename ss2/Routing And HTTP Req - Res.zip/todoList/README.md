# Slides
https://www.canva.com/design/DAFgif8v2e4/NMtkMDCfY5jR-nQJVV2vug/view?utm_content=DAFgif8v2e4&utm_campaign=designshare&utm_medium=link&utm_source=publishsharelink#1

# Todo list

[x] Hiển thị danh sách todo
[x] Thêm mới todo
[] Cập nhật todo
[] Xoá todo
